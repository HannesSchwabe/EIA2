
interface AssocStringString {
    [key: string]: string;
}

interface Player {
    name: string;
    score: string;
}
